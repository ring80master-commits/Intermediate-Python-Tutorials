#update operation
#Updating a specific record
#record ->tuple->row

import sqlite3

conn=sqlite3.connect("actors.db")
cursor=conn.cursor()

#single record updation
#uq="Update actors set no_of_films=? where name=?"
#cursor.execute(uq, (110, "Meena Kumari"))

#multiple columns updation in 1 row
#uq="Update actors set name=?, no_of_films=? where id=?"
#cursor.execute(uq, ("Amitabh Bacchan", 1000, 2))

#multiple rows updation
#uq="update actors set no_of_films=no_of_films+1 where no_of_films>=200"
#cursor.execute(uq)

#user input
#name=input("Enter actor name...\n")
#no_of_films=int(input("Enter number of films... \n"))

#uq="Update actors set no_of_films=? where name=?"
#cursor.execute(uq, (no_of_films, name))

#Update all records

uq="Update actors set no_of_films=666"
cursor.execute(uq)
conn.commit()

conn.close()