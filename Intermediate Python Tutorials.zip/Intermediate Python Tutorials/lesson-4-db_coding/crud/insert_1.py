#Data base programming
#base database sqlite3

#Insert operatio- 1 record

import sqlite3

conn=sqlite3.connect("actors.db")
cursor=conn.cursor()

ctq="""Create table if not exists actors(
id integer primary key autoincrement,
name text, no_of_films integer
)
"""
cursor.execute(ctq)

cursor.execute(
"insert into actors(name, no_of_films) Values(?, ?)",
("Ritik Roshan", 100))

conn.commit()

conn.close()
