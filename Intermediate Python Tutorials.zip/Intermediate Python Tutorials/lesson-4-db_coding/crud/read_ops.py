#Read operation
import sqlite3

conn=sqlite3.connect("actors.db")
cursor=conn.cursor()

#cursor.execute("select * from actors")

#rows=cursor.fetchall()
#for r in rows:
#    print(r)

#row=cursor.fetchone()
#print(row)#print 1st record

#rows=cursor.fetchmany(3)
#for r in rows:
#    print(r)

#cursor.execute("select name from actors")
#rows=cursor.fetchall()
#for r in rows:
#    print(r)

cursor.execute("select * from actors where no_of_films>200")
rows=cursor.fetchall()
for r in rows:
    print(r)
conn.close()