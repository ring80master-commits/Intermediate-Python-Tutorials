#Delete operation
#deleting a single record
import sqlite3

conn=sqlite3.connect("actors.db")
cursor=conn.cursor()


    
#dq="Delete  from actors where name=?"
#cursor.execute(dq, ("Amitabh Bacchan",))

#cursor.execute(
#"delete from actors where id=?", (1,)
#)

#deleting multiple records

#cursor.execute(
#"delete from actors where no_of_films<500"
#)


#delete all records
#cursor.execute(
#'delete from actors'
#)

#to check how many rows deleted
#print("Rows deleted:", cursor.rowcount)

#user input deletion
#name=input("Enter actor name to be deleted...\n")
#cursor.execute(
#"Delete from actors where name=?", 
#(name,)
#)

#cursor.execute("select * from actors")
#rows=cursor.fetchall()
#for r in rows:
#    print(r)

#delete table
#cursor.execute("drop table actors")

conn.commit()

conn.close()
