#Insert multiple values
import sqlite3

conn=sqlite3.connect("actors.db")
cursor=conn.cursor()

ctq="""Create table if not exists actors(
id integer primary key autoincrement,
name text, no_of_films integer
)
"""
cursor.execute(ctq)

actors_data=[
("Ranveer Singh", 200),
("Deepika Padukone", 440),
("Akshay Khanna", 550),
("Vijay Anand", 390)
]

cursor.executemany(
"insert into actors(name, no_of_films) Values(?, ?)",
actors_data
)

conn.commit()

conn.close()