#Having
"""
Having clause is used to filter groups
made by group by clause.

Where filters rows
Having filters groups

select col_name, aggregate_function(col_name)
from table_name
group by col_name
having condition;

Where
-filters rows
-comes before group by
-aggregate_functions are not used

Having
-filters groups
-comes after group by 
-aggregate_functions are used
"""

import sqlite3

conn=sqlite3.connect("company.db")
cursor=conn.cursor()

#cursor.execute("""
#select dept, count(*)
#from employees
#group by dept
#having count(*)>1
#""")

#cursor.execute("""
#select dept, sum(salary)
#from employees
#group by dept
#having sum(salary)>70000
#""")

#cursor.execute("""
#select dept, count(*)
#from employees
#where salary >45000
#group by dept
#having count(*)>=1
#""")

"""Get those depts whose tota salary is more
"""
cursor.execute("""
select dept, sum(salary)
from employees
group by dept
having sum(salary)>80000
""")

rows=cursor.fetchall()
for row in rows:
    print(row)
conn.close()

"""Important rules:
1. Having always comes after group by 
2. Used with aggregate functions like
count, sum, avg.
3. Don't use having like u use where clause
"""