#1. Where clause
"""Where clause is used when u want to get
specific rows based on specific conditions.

select col1, col2
from table_name
where condition;
"""
import sqlite3

conn=sqlite3.connect("company.db")
cursor=conn.cursor()

cursor.execute("""
create table if not exists employees(
id integer primary key,
name text, age integer,
salary integer, dept text
)
""")

cursor.execute("Delete from employees")

data=[
(1, "Amit", 25, 60000, "IT"),
(2, "Neha", 33, 76000, "HR"),
(3, "Rajiv", 44, 87000, "IT"),
(4, "Pragya", 29, 55499, "Sales"),
(5, "Amita", 30, 43800, "IT"),
(6, "Mohita", 33, 102600, "HR"),
(7, "Ashish", 29, 30000, "Sales"),
(8, "Vinay", 20, 24000, "Store")

]

cursor.executemany("insert into employees values(?,?,?,?,?)", data)
conn.commit()

conn.close()