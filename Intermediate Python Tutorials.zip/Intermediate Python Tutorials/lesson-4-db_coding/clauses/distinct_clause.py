#3. distinct
"""It is used to remove duplicate values.
In simple words-> give me unique values, 
not duplicate ones.

select distinct col_name from table_name;

"""
import sqlite3

conn=sqlite3.connect("company.db")
cursor=conn.cursor()

#cursor.execute("select distinct dept from employees")

#cursor.execute("""
#select distinct dept, salary from employees
#""")

#Filtering-> distinct+where
#cursor.execute("""
#select distinct dept from employees
#where salary>50000
#""")

#How many depts. in the company?
cursor.execute("select distinct dept from employees")

rows=cursor.fetchall()
#for row in rows:
#    print(row)
print("Depts:", rows)
print("Total:", len(rows))

"""get the depts of those employees
whose Salary>30000 
"""

conn.close()