#in/not in
"""
When matching is for more than one value.

Select col_name
from table_name
where col_name in (val1, val2, ..valn);

Select col_name
from table_name
where col_name not in (val1, val2, ..valn);

"""
import sqlite3

conn=sqlite3.connect("company.db")
cursor=conn.cursor()

#cursor.execute("""
#select * from employees
#where dept in("IT", "Store")
#""")


"""In vs. OR
In clause basically simplifies multiple or 
conditions
"""
#cursor.execute("""
#select * from employees
#where dept ='IT' or dept='Store'
#""")

#cursor.execute("""
#select * from employees
#where salary in(30000, 76000)
#""")


#cursor.execute("""
#select name, dept from employees
#where dept in('IT', 'HR') and salary>50000
#""")

"""Shortlist employees for interview from 
selected depts.
"""

rows=cursor.fetchall()
for row in rows:
    print(row)

conn.close()
