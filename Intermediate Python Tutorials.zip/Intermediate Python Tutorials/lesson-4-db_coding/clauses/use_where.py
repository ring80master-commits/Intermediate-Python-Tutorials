#using where clause
import sqlite3

conn=sqlite3.connect("company.db")
cursor=conn.cursor()

cursor.execute("""
create table if not exists employees(
id integer primary key,
name text, age integer,
salary integer, dept text
)
""")

#cursor.execute("select * from employees where salary>60000")
#cursor.execute("select name from employees where dept='IT'")
#cursor.execute("""
#select * from employees
#where dept='IT' or salary>60000
#""")

name=input("Enter name.... ")
#query=f"select * from employees where name='{name}'"
#cursor.execute(query)
#unsafe because it leads to sql injection attack
cursor.execute("select * from employees where name=?", (name,))

rows=cursor.fetchall()
for row in rows:
    print(row)

"""Task: find employees whose salary >45000
and belongs to Purchase.
for this u need to insert more records.
 age>=30
SALARY<50000
"" and/or 

"""
conn.close()
