#Group by
"""This clause is used to group/divide data
according to categories(group)
and then on those groups calculations
(aggregation) is done.

Group the data and perform calculations
on those groups.

select col_name, 
aggregate_function(col_name)
from table_name
group by col_name;

count() number of records
sum() total
avg() average
max() min()
"""
import sqlite3

conn=sqlite3.connect("company.db")
cursor=conn.cursor()

#cursor.execute("""
#select dept, count(*)
#from employees
#group by dept
#""")

#cursor.execute("""
#select dept, sum(salary)
#from employees
#group by dept
#""")

#cursor.execute("""
#select dept, avg(salary)
#from employees
#group by dept
#""")

#cursor.execute("""
#select dept, count(*)
#from employees
#where salary>30000
#group by dept
#""")

"""In the firm bring the 
dept. name of how much is 
the  total salary.
"""
#cursor.execute("""
#select dept, sum(salary)
#from employees
#group by dept
#""")

rows=cursor.fetchall()
for row in rows:
    print(row)

conn.close()
