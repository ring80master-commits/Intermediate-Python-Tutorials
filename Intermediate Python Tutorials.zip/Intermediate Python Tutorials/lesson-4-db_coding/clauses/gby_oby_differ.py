#difference between order by & group by

"""group by
-Divides data into group(categories)
- makes group
-Used with aggregate functions
-combines data

order by
-Arrange data in ascending/descending order
-does sorting
-changes display order
-rearrange data

"""

import sqlite3

conn=sqlite3.connect("company.db")
cursor=conn.cursor()

#group by
#print("Group by result:\n")
#cursor.execute("""
#select dept, count(*)
#from employees
#group by dept
#""")

#rows=cursor.fetchall()
#for row in rows:
#    print(row)

#print("\nOrder by result:\n")
#order by
#cursor.execute("""
#select name, salary
#from employees
#order by salary desc
#""")

cursor.execute("""
select dept, sum(salary)
from employees
group by dept
order by sum(salary) desc
""")

rows=cursor.fetchall()
for row in rows:
    print(row)

#Group by =make a group of items
#Order by=Make the items in the line

conn.close()
