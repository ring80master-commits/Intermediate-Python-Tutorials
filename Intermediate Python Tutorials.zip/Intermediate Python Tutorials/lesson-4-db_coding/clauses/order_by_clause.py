#2. order by
"""
data is shown in sorted format

select c1, c2 from table_name
order by col_name asc|desc;
"""

import sqlite3

conn=sqlite3.connect("company.db")
cursor=conn.cursor()

#cursor.execute("select * from employees order by salary desc")

#cursor.execute("select name, age from employees order by age")

#cursor.execute("""
#select * from employees
#order by dept asc, salary desc
#""")

#cursor.execute("""
#select name, salary from employees
#where dept='IT'
#order by salary
#""")

#show top earners list
#cursor.execute("""
#select name, salary from employees
#order by salary desc
#limit 3
#""")

#top n records=order by +limit n

"""1. get employees name according to asc
2. get list of employees according to salary
in desc order
3. Sort it dept employees according to age(desc)
"""
rows=cursor.fetchall()
for row in rows:
    print(row)


conn.close()