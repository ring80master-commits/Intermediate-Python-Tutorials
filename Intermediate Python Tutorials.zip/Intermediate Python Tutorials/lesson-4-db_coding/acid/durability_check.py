#durability check
import sqlite3

conn=sqlite3.connect("durability.db")
cursor=conn.cursor()

print("Reading data after reopening database:\n")
for r in cursor.execute("select * from users"):
    print(r)
conn.close()
