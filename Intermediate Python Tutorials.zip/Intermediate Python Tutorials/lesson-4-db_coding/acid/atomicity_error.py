#1. Atomicity
#Example1:with error
#transaction will be unsuccessful

import sqlite3

conn=sqlite3.connect("bank.db")
cursor=conn.cursor()

try:
    cursor.execute("Create table if not exists accounts (name text, balance integer)")
    #clean old data for repeated runs
    cursor.execute("delete from accounts")
    
    cursor.execute(
    "Insert into accounts values('A', 1000)")
    cursor.execute(
    "Insert into accounts values('B', 500)")
    conn.commit()
    
    print("Before Transaction...\n")
    for r in cursor.execute("select * from accounts"):
        print(r)
    
    #deduct from A
    cursor.execute("Update accounts set balance=balance-500 where name='A'")
    
    #force error
    raise Exception("Something went wrong after deduction.")
    
    #this line will never execute
    #add to B
    cursor.execute("Update accounts set balance=balance+500 where name='B'")
    conn.commit()
except Exception as e:
    print("Error Occured:", e)
    conn.rollback()
    print("\n After Rollback:")
    for r in cursor.execute("select * from accounts"):
        print(r)
    print("\nTransaction Rolled Back!")
finally:
    conn.close()