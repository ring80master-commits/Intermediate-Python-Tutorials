#2. Consistency(Rule of valid data)

"""Consistency ensures that the database
always remains in a valid state before 
& after the transaction.

-Data must follow all rules, constraints & 
conditions.

- after transaction-> db should not became invalid

0-100

How is consistency is maintained.
-primary key
not null
Unique
check
foreign key
"""

import sqlite3

conn=sqlite3.connect("school.db")
cursor=conn.cursor()

try:
    cursor.execute("""Create table if not exists 
    students (name text, 
    marks integer check(
    marks>=0 and marks<=100))""")
    
    #clean old data for repeated runs
    cursor.execute("delete from students")
    
    cursor.execute(
    "Insert into students values('Aman', 80)")
    
    #invalid data
    cursor.execute(
    "Insert into students values('Ashish', 180)")
    conn.commit()

except Exception as e:
    print("Error:", e)
    conn.rollback()

finally:
    print("\nFinal data in the table:\n")
    for r in cursor.execute("select * from students"):
        print(r)
    conn.close()