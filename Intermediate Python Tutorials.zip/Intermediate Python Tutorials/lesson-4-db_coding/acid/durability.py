#4. Durabilty(Permanent storage guarantee)
"""Durablity ensures that once a transaction
is committed, the data is permanently
saved in database- even if the system
crashes.

key idea:
    data is written on the disk
    it survives the crashes
commit()
"""

import sqlite3

#step1
conn=sqlite3.connect("durability.db")
cursor=conn.cursor()

cursor.execute("Create table if not exists users (name text)")
#clean old data for repeated runs
cursor.execute("delete from users")
cursor.execute(
"Insert into users values('Ajay')")

conn.commit()
print("Data inserted and Committed.")

conn.close()

"""CRUD-> operations in db
ACID-> Shows impartance and relaibilty of
your system. Backbone of all modern db.
"""
