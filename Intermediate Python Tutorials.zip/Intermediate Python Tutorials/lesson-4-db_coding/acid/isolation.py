#3. I-> Isolation(Independent transactions)

"""Isolation ensures that multiple transactions
execute independently without interfaring
with each other.

One transaction should not see the intermediate
(incomplete) state of other transaction.

Why Isolation?

In real world:-
-multiple users access database at the same time
-Multiple transactions run simultaneously

Without isolation:-
- data conflicts may occur
- wrong results will be shown

Key problems without isolation
1. Dirty read
2. Non-repeatable read
3. Phantom read

Transaction
Locks(internally managed)
SQLite uses serializable isolation level(by default)

"""
import sqlite3

conn1=sqlite3.connect("bank.db", isolation_level='DEFERRED')
cursor1=conn1.cursor()

conn2=sqlite3.connect("bank.db", isolation_level='DEFERRED')
cursor2=conn2.cursor()

cursor1.execute("create table if not exists accounts(name text, balance integer)")
cursor1.execute("delete from accounts")
cursor1.execute("Insert into accounts values('A', 1000)")
conn1.commit()

#transaction 1 begins
cursor1.execute("Begin")
cursor1.execute("update accounts set balance =balance-500 where name='A'")

print("Transaction 1 update balance but not committed.")


#transaction 2 tries to read
print("\nTransaction 2 reading balance:\n")
for r in cursor2.execute("select * from accounts"):
    print(r)

#commit transaction 1
conn1.commit()

print("\nAfter commit, transaction 2 reads:\n")
for r in cursor2.execute("select * from accounts"):
    print(r)
    
conn1.close()
conn2.close()