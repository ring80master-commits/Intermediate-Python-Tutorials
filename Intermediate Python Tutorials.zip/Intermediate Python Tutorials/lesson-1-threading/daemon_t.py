#Daemon Thread
"""A daemon thread is a background thread that:
    Automaticlly stops when the main program
    exits.

runs in the background
does not block program exit
used for:
    monitoring
    logging
    background services
"""
import threading, time

def background_task():
    while True:
        print('Running in background....')
        time.sleep(1)

def task():
    for i in range(5):
        print("Working...")
        time.sleep(1)
t=threading.Thread(target=background_task)

t.daemon=True
t.start()
print('Main program ends')

"""Auto - sync
Auto-save 
logging system
cpu usage

Gil vs. daemon thread
gil:
    only 1 thread executes at a time
    bad for cpu bound task
    good i/o bound task

daemon thread:
    background task
    stops automatically
    does not block program exit

"""
