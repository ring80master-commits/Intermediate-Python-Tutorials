#Global Interpreter Lock(GIL)
"""GIL is a mechanism in CPython that:
    Allows only 1 thread to execute Python
    bytecode at a time.
    
Why does GIL exists?
Memory magt.
how?
1. Thread-safe(no race conditions on object)
2. Faster for single threaded program.

"""
import threading, time

#def task():
#    for _ in range(10**7):
#        pass

#t1=threading.Thread(target=task)
#t2=threading.Thread(target=task)

#t1.start()
#t2.start()

#t1.join()
#t2.join()

"""
when:
    waiting for network
    file read
    api calls
"""
#def download():
#    print("Start downloading....")
#    time.sleep(1)
#    print("Download complete.")

#t1=threading.Thread(target=download)
#t2=threading.Thread(target=download)

#t1.start()
#t2.start()
#t1.join()
#t2.join()

#Thread is useful when
#task type is cpu bound not i/o bound

#how to bypass gil?
from multiprocessing import Process
"""
Each process has:
    1. separate memory
    2. separate python interpretor
    3. no shared gil
    10 students thread
    1 ct gil
    
"""