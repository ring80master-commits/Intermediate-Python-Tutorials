#daemon more execution example
import threading, time

def download():
    print("Start downloading....")
    time.sleep(1)
    print("Download complete.")

t1=threading.Thread(target=download)
t2=threading.Thread(target=download)

t1.daemon=True
t2.daemon=True

t1.start()
t2.start()

#t1.join()
#t2.join() #irrelevent

"""
t1.daemon=True
t2.daemon=True

t1.join()
t2.join()
it is a pointless trick.
daemon->True--> Don't wait for me
join()-> wait for me

daemon =True -> I am background, don't wait
join() Wait untill I finish

Thread configuration like daemon must be 
done before starting the thread.
"""


print("Main thread finishes.")
"""
A. Without join()
1. Thread start
2. Main thread does NOT wait explicitely
3. But python still waits implicitely because
there is non-daemon threads
Python will Not exit until all non-daemon threads
finish

B. with join()
t1.join()
t2.join()

1. Main thread explicitly wait
2. Ensures both threads complete before
moving ahead.

C. without join()
t1.start()
t2.start()
print("Main thread finishes.")

D. with join()
t1.start()
t2.start()

t1.join()
t2.join()
print("Main thread finishes.")


Summary:

Concept -- Without join() -- with join()

1. Main thread
waits?            -- No ----- Yes

2. Program exists
early? -----         No(because 
                            of non-daemon)--- No

3. Execution 
control ------    Loose ---- Controlled

join() does not make threads run -- 
it makes the main thread WAIT.

"""
