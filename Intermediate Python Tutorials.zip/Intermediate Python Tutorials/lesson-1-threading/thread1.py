#Threading in python
"""Threading allows a program to run
multiple task concurently within the same 
process.
User input,
process, 
user if err show
download
printing
result

t1->t2->t3

t1
t2 -> run simultaneously
t3

Process Vs. Thread

1. Independent program Vs. sub-task of a process

2. separate memory Vs. shared memory

3. Slower Vs. Faster

4. Difficult Vs. Easy

Download
show progress
save file


Why threading?
I/O Related task there we use threading.
File download
web scraping
network communication
waiting for an api response
gui applications

without threading
Download file1 (wait)
download file2(wait)
download file3(wait)

threading

create, start, synchronize


"""

import threading, time
#def disp():
#    for i in range(3):
#        print("Hello thread!")
#        
#t=threading.Thread(target=disp)
#t.start()

#disp()


"""Thread()-> creates a thread
target-> function to run the thread
start()-> start the thread
"""
#def task1():
#    for i in range(3):
#        print("Task 1 running!")

#def task2():
#    for i in range(3):
#        print("Task 2 running!")

#t1=threading.Thread(target=task1)
#t2=threading.Thread(target=task2)
#t1.start()
#t2.start()

#Thread with args

#def disp(name):
#    print("Hello", name)

#t=threading.Thread(target=disp, args=("Python", ))
#t.start()

#Joining threads

#def task():
#    print("Thread runnning!")
#    print(threading.current_thread().name)
#    

#t=threading.Thread(target=task)
#t.start()   
#t.join()
#print("Program Finished!")

"""Main thread waits untill child threadfinishes.
"""

#Main thread Vs. Child thread
"""
MT-- CT1
    --CT2
    

"""
#print(threading.current_thread().name)

#using time delay
def task(name):
    for i in range(3):
        print(name, " running")
        time.sleep(1)

t1=threading.Thread(target=task, args=("Thread-1", ))
t2=threading.Thread(target=task, args=("Thread-2", ))
t3=threading.Thread(target=task, args=("Thread-3", ))

t1.start()
t2.start()
t3.start()

#GIL--> Global Interpreter Lock
"""Only 1 thread executes python bytecode
at a time.
I/O network, waiting
"""
