#To get ur own IP Address
import socket

def get_ip():
    try:
        """We use a UDP connection to a public DNS(Google)
        to find the interface used for external traffic.
        """
        s=socket.socket(socket.AF_NET, socket.SOCK_DGRAM)
        #AF_NET->IPv4 will get used
        # SOCK_DGRAM -> UDP PROTOCOL
        s.connect(("8.8.8.8", 80))
        ip=s.getsocketname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def mask_ip(ip, mode="full"):
    parts=ip.split('.')
    if mode=="full":
        return "x.x.x.x"
    elif mode=="partial" and len(parts)==4:
        return f"{parts[0]}.{parts[1]}.x.x"
    else:
        return ip

#1. Get & show the masked ip initially
real_ip=get_ip()
masked_id=mask_ip(real_ip, "full")
print(f"Device IP(MASKED):{masked_id}")

#2. Ask the user if they want to reveal the real ip
choice=input("\n Did you want to see ur real ip address?")
if choice=="yes":
    print(f"Your original IP address:{real_ip}")
else:
    print("OK. Bye Bye!")
