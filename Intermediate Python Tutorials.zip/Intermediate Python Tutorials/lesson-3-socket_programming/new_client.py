# new client code

import socket
import threading

print("To end the chat, just type 'exit'.")

def receive_messages(client):
    while True:
        try:
            msg = client.recv(1024).decode()
            if not msg:
                break

            if msg.lower() == "exit":
                print("\nServer ended the chat.")
                client.close()
                break

            print("\nServer:", msg)

        except:
            break

def send_messages(client):
    while True:
        msg = input("Client: ")

        client.send(msg.encode())

        if msg.lower() == "exit":
            print("You ended the chat.")
            client.close()
            break

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_ip="192.132.9.2" #replace it with ur original server ip
client.connect((server_ip, 9999))

threading.Thread(target=receive_messages, args=(client,)).start()
threading.Thread(target=send_messages, args=(client,)).start()

"""This script to be written on oppo a54 which
is out client node.


"""