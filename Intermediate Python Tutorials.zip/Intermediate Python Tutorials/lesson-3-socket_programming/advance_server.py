import socket
import threading

print("To end the chat, just type 'exit'.")

# 🔐 Mask IP function
def mask_ip(ip):
    parts = ip.split('.')
    if len(parts) == 4:
        return f"{parts[0]}.{parts[1]}.x.x"
    return "Hidden"

def receive_messages(client_socket):
    while True:
        try:
            msg = client_socket.recv(1024).decode()

            if not msg:
                break

            if msg.lower() == "exit":
                print("\nClient ended the chat.")
                client_socket.close()
                break

            print("\nClient:", msg)

        except:
            break

def send_messages(client_socket):
    while True:
        try:
            msg = input("Server: ")
            client_socket.send(msg.encode())

            if msg.lower() == "exit":
                print("You ended the chat.")
                client_socket.close()
                break

        except:
            break

# 🔥 Server setup
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind(("0.0.0.0", 9999))
server.listen(1)

print("Server is waiting...")

client_socket, addr = server.accept()

# 🔥 Extract real IP
client_ip, client_port = addr
real_ip = client_ip

# 🔥 Masked IP for display
masked_ip = mask_ip(client_ip)

print(f"Client connected: {masked_ip}:{client_port}")

# 🔐 Optional admin access
choice = input("Do you want to see full client IP? (yes/no): ").strip().lower()
if choice == "yes":
    print(f"Full IP: {real_ip}:{client_port}")
else:
    print("IP hidden for privacy.")

# 🔥 Start threads
threading.Thread(target=receive_messages, args=(client_socket,)).start()
threading.Thread(target=send_messages, args=(client_socket,)).start()