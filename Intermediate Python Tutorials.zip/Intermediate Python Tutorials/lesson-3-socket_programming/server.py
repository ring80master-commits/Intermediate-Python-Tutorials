#server side script
#connevtion between server & client
"""Oppo a54-- client
oppo f29-- server
Connectio establishing using wifi
"""
import socket

def mask_ip(ip):
    parts=ip.split('.')
    if len(parts)==4:
        return f"{parts[0]}.{parts[1]}.x.x"
    return ip

server=socket.socket(socket.AF_INET,
socket.SOCK_STREAM)
"""AF_INET: Specifies Address Family. 
INET refers to IPv4(the standard 192.132.x.x style address)

SOCK_STREAM: Defines Socket type. 
STREAM means TCP
"""
server.setsockopt(socket.SOL_SOCKET,
socket.SO_REUSEADDR, 1)
"""The Problem: Normally, when u stop a 
python program, the os keeps the port busy
for minute or 2(a state called as TIME_WAIT).
If u try to run ur cide again immdiatly, you will
get an "Address already in use" error.

Solution: If this port is in wait state, let me take 
back immdiatly. It saves u from waiting for 60 seconds
every time u restart ur server during testing.

SOL: Socket Level
By using SOL_SOCKET u r saying I want to change
a setting that applies to socket itself

SO_REUSEADDR: 
SO:- Socket Option
REUSEADDR: Reuse address
1->True(on)
0->False(off)
"""
server.bind(("0.0.0.0", 9999))
server.listen(1)

print("Server is waiting...\n")

client_socket, addr=server.accept()

client_ip, client_port=addr

masked_ip=mask_ip(client_ip)

x="Do you want to see full client details? (yes/no): "
choice=input(x).strip().lower()

if choice=="yes":
    print(f"Client full details: {client_ip} : {client_port}")
else:
    print("OK, Bye Bye!")

data=client_socket.recv(1024).decode()
print("Client says:", data)

client_socket.send("Hello from Server!".encode())
client_socket.close()
server.close()
