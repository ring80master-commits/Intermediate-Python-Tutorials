#client side script
import socket

client=socket.socket(socket.AF_INET, 
socket.SOCK_STREAM)

server_ip="192.132.9.2" #replace it with ur original server ip
client.connect((server_ip, 9999))
client.send("Hello Server!".encode())

data=client.recv(1024).decode()
print("Server says:", data)

client.close()
