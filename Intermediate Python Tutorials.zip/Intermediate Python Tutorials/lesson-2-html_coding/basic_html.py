"""Python=logic backend
HTML= A structured UI/frontend

Django, fastapi, flask, streamlit, PyQt5, PySide
Backend work is done by python.
server interaction, login system, database

html- UI/frontend
web apps 
gui emails send
otp data visilualization dashbords landing page

emi calculator
"""

"""HTTP=> A protocol used for communication
between:-
Browser(client)
Server

Simple Flow:-
1. Browser request-> http://localhost:8000

http://127.0.0.1:8000/
2. Python server receives request
3.Server send html response
html parser
4. Browser displays it
HTTPS Security 

"""

from http.server import BaseHTTPRequestHandler as BHRH, HTTPServer
"""
BaseHTTPRequestHandler->Handles incoming requsts
HTTPServer-> Creates and runs the server
"""
#class MyHandler(BHRH):
#    def do_GET(self):
#        self.send_response(200)
#        #200-> success, 400->not found
#        self.send_header("Content-type", "text/html")
#        self.end_headers()
#        name="Will Smith"
#        html=f'''<html>
#        <body>
#        <h1>Hello from Python Server to {name}</h1>
#        </body>
#        </html>
#        '''
#        self.wfile.write(html.encode())
#        #Converts string-> bytes->send to browser

#server=HTTPServer(("localhost", 8000), MyHandler)
#print("Server running at http://127.0.0.1:8000")
#server.serve_forever()
        

class MyHandler(BHRH):
    def do_GET(self):
        if self.path=='/':
            content="<h1>Home Page</h1>"
        elif self.path=='/about':
            content="<h1>About Page</h1>"
        else:
            content="<h1>404 Page Not Found</h1>"
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(content.encode())
        
server=HTTPServer(("localhost", 8000), MyHandler)
print("Server running at http://127.0.0.1:8000")
server.serve_forever()
